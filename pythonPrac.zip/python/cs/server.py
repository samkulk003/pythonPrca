import socket

def mpm():
    host='127.0.0.1'
    port=6000

    s=socket.socket()
    s.bind((host,port))
    s.listen(1)
    print("waiting for connection...")

    c,adrr=s.accept()
    print("connection established")
    print("Client ADD: ",adrr)

    while True:
        try:
            print()
            data=c.recv(1024)
            d=data.decode('ascii')
            print("Client :",d)
            print()
            x=input("eneter new messgae")
            y=x.encode('ascii')
            c.send(y)

        except KeyboardInterrupt:
            print()
            print("connection terminated!")
            break

mpm()