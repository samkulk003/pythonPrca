import mysql.connector

mydb=mysql.connector.connect(
    host='localhost',
    user='root',
    password='p@ssw0rd',
    database="samy"
)

mycursor=mydb.cursor()

mycursor.execute("alter table cupboad add year int(4)")             
mydb.commit()
#print(mycursor.rowcount,'record updated')
#myresult=mycursor.fetchall()



'''for x in myresult:
    print(x)'''




