import mysql.connector

mydb=mysql.connector.connect(host='localhost',
    user='root',
    password='p@ssw0rd',
    database='samy'
)

mycursor=mydb.cursor()
mycursor.execute("drop table test")
mydb.commit()



    