def fibo(n):
    if n==1:
        print('0')
    a=0
    b=1
    print(a)
    print(b)
    if(n>=2):
        for i in range(n-1):
            c=a+b
            a=b
            b=c
            print(c)
        
def leap(n):
    if n%4==0:
        if n%100==0:
            if n%400==0:
                print("yes")
            else:
                print("no")
        else:
            print("no")
    else:
        print("no")

def hist(l):
    count_dict={}
    for i in l:
        count_dict[i]=count_dict.get(i,0)+1
    count_pairs=list(count_dict.items())
    count_pairs.sort(key=lambda x:(x[1],x[0]))
    return count_pairs


def hanoi(n,source,target,aux):
    if n==1:
        print(f"disk 1 moves from {source} to {target}")
        return
    hanoi(n-1,source,aux,target)
    print(f"disk {n} moves from {source} to {target}")
    hanoi(n-1,aux,target,source)


def tp(a,b):
    max=lambda a,b: a if a>b else b
    print(max(a,b))

def list_add(l1,l2):
    result=list(map(lambda a,b:a+b,l1,l2))
    print(result)

def cube(l):
    result=list(map(lambda x:x**3,filter(lambda x:x%2==0,l)))
    print(result)


fibo(5)
leap(2000)
hanoi(3,'a','b','c')
print(hist([1,1,13,14,1,5,13,5,7,7,7]))
tp(10,20)
list_add([1,2,3],[1,2,3])
cube([1,2,3,4,5])