def t1():
    for i in range(0,4):
        print('*'*i)
def t2():
    for i in range(4,0,-1):
        print('*'*i)
def t3():
    for i in range(0,4):
        print(' '*(4-i)+'*'*i)
def t4():
    for i in range(4,0,-1):
        print(' '*(4-i)+'*'*i)
def t5():
    for i in range(0,4):
        print(' '*(4-i)+'*'*(2*i-1))
def t6():
    for i in range(0,4):
        print(' '*(4-i)+'*'*(2*i-1))
    for i in range(4,0,-1):
        print(' '*(4-i)+'*'*(2*i-1))

t1()
print()
t2()
print()
t3()
print()
t4()
print()
t5()
print()
t6()