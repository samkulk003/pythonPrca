class sam:
    a=10
s=sam()
print(s.a)

class person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def printName(self):
        print(self.name,self.age)

p1=person(input("enter name"),input("enter age"))
p1.printName()
p1.name="rani"
p1.printName()
print("age is ",p1.age)
del p1.age
del p1
print(p1.name)