class Employee:
    def __init__(self,name):
        self.name=name
class developer(Employee):
    def __init__(self, name):
        super().__init__(name)
class tester(Employee):
    def __init__(self,name):
        super().__init__(name)
class manager(Employee):
    def __init__(self, name):
        super().__init__(name)
        self.employees=[]
    
    def add_employee(self,employee):
        if isinstance(employee,(developer,tester)):
            self.employees.append(employee)
            print(f"{employee.name} added to {self.name}'s team")
        else:
            print("can only add developer or tester")
    def remove_employee(self,employee):
        if employee in self.employees:
            self.employees.remove(employee)
            print(f"{employee.name} removed from {self.name}'s team")
        else:
            print("not a developer or tester")
    
    def display_employees(self):
        print(f"{self.name}'s team :")
        for employee in self.employees:
            print(f" - {employee.name}")

mang=manager("Alice")
dev1=developer("bob")
dev2=developer("sam")
test=tester("cam")

mang.add_employee(dev1)
mang.add_employee(test)
mang.add_employee(dev2)
mang.display_employees()

mang.remove_employee(dev1)
mang.display_employees()