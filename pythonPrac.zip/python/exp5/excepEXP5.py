import math

try:
    imp="import "+input("enter the module to import : ")
    exec(imp)
    n={}
    n1,n2,k1,k2=eval(input("enter 2 no and their keys seperated by commas :"))
    n[k1]=n1
    n[k2]=n2
    k1,k2=eval(input("enter ey of no seperated by commas :"))
    result=n[k1]/n[k2]
    m=int(input("enter one or more no"))
    print("result is : ",result/math.sqrt(m))
    if(n[k1]==0):
        raise RuntimeError
except ValueError:
    print("Invalid literal.")
except ImportError:
    print("module not found")
except ZeroDivisionError:
    print("division by zero value")
except RuntimeError:
    print("meaningless")
except KeyboardInterrupt:
    print()
    print("program was interrupted")
except:
    print("something wrong in input")
else:
    print("no exception")
finally:
    print("executed")

