class BaseError(Exception):
    pass
class HighValueError(Exception):
    pass
class LoeValueError(Exception):
    pass

value=29

while(1):
    try:
        n=int(input("enter no :"))
        if n>value:
            raise HighValueError
        elif n<value:
            raise LoeValueError
    except LoeValueError:
        print("value low")
    except HighValueError:
        print("value high")
    else:
        print("no error best")
        break
