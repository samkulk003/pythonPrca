f1= open("T1.txt","r")
f=f1.read()
f=f.split()
l=[]
for i in f:
    l.append(i[::-1])
    l.sort(key=lambda x:(x,len(x)))
print("sorted")
print(l)

f2=open("T2.txt","w")
for i in range(len(l)):
    f2.write(str(l[i])+"\n")




















'''n=int(input("enetr the count of no"))
print("enter the numbers")
l=[]

with open("T1.txt","w") as f:
    for i in range(n):
        f.write(str(input()) + "\n")
        
    #f.write(str(input()))   
with open("T1.txt","r") as f1:
    for x in f1:
        l.append(int(x))
l.sort()



with open("T2.txt","w") as f2:
    for i in l:
        f2.write(str(i) + "\n")
    #f2.write(str(l[n-1]))'''
