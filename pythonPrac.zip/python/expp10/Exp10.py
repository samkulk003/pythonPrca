import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv("C://Users//Shekhar Kulkarni//Downloads//country_full.csv")
import numpy as np
x=np.array(['a','b','c'])
y=np.random.normal(50,10,60)
plt.hist(y)
plt.show()