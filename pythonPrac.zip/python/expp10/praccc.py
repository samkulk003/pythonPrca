import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df=pd.read_csv("C:\\Users\\Shekhar Kulkarni\\Downloads\\archive\\House_Rent_Dataset.csv")
print(df.head())
na=df.isna().sum()
print(na)

x=df['Size'].iloc[0:].values
y=df['Rent'].iloc[0:].values

plt.scatter(x,y)
plt.xlabel("size")
plt.ylabel("rent")

plt.show()