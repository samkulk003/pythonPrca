import re

# Read the file
file = open("regex\\txt.txt")
txt = file.read()
file.close()

# Patterns
pattern_names = r'M\w*.\s*\w*\s*\w*[\n]'
pattern_email = r'[a-zA-Z0-9\.\-+_]+@[a-zA-Z0-9\.\-+_]+\.[a-zA-Z]+'
web_pattern = r"(https?:\/\/)([a-z0-9]+\.[a-z\.]+)"
phone_pattern = r'[0-9]+[#\-*]*[0-9]+[#\-*]*[0-9]+'

# Find all matches
names = re.findall(pattern_names, txt)
websites = re.findall(web_pattern, txt)
emails = re.findall(pattern_email, txt)
phone_numbers = re.findall(phone_pattern, txt)

# Processing and printing
print("Names are:")
for name in names:
    print(name.strip())

print("\nWebsites are:")
for protocol, domain in websites:
    print(domain)

print("\nEmail addresses are:")
for email in emails:
    print(email)

print("\nUsernames and domains of each of the email addresses are:")
for email in emails:
    user, domain = email.split('@')
    print(f"User Id.: {user}; Domain: {domain}")

print("\nPhone numbers are:")
for number in phone_numbers:
    print(number)
