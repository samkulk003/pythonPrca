import re

file=open("txt.txt")
txt=file.read()

pattern_names=r'M\w*.\s*\w*\s*\w*[\n]'
pattern_email=r'[a-zA-Z0-9\.\-+_]+@[a-zA-Z0-9\.\-+_]+\.[a-zA-Z]+'

namesl=re.findall(pattern_names,txt)
names=[]
for i in namesl:
    names.append(i)
print("names are :")
for i in names:
    print(i[:-1])

web=r"(https?:\/\/)?([a-z0-9]+)\.([a-z\.]+)"
websites=re.findall(web,txt)

print("webs are:")

for i in websites:
    if 'https://' in i[0]:
        print(i[0][8:])
    elif 'http://' in i[0]:
        print(i[0][7:])
    else:
        print(i[0])
print()

emails=re.findall(pattern_email,txt)

print("email addresses are :")
for i in emails:
    print(i)
print()

user=r'[^@]+'
dom=r'(?<=@)[^@]+'
usernames=re.findall(user,txt)
domains=re.findall(dom,txt)

print("usernames and doamins of each emails  are :")

for i,j in zip(usernames,domains):
    print("user id : ",i[:-1], " domain : ",j[:-1])
    print()

num=r'[0-9]+[#\-*]*[0-9]+[#\-*]*[0-9]+'
numbers=re.findall(num,txt)

